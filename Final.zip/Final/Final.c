#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int _add(int a, int b);
int add(int a, int b);

//======================================================================================================//

int main()
{

    FILE *file = fopen("Numbers_file.txt", "r");
    int integers[1000];
    int i = 0;
    int num;
    int total = 0;
    int n;

    while (fscanf(file, "%d", &num) > 0)
    {

        integers[i] = num;
        // open code down below to see file numbers
        //printf("Numbers in file: %d \n", num);
        i++;
    }
    n = i;

    fclose(file);

    for (i = 0; i < n; i++)
    {
        total = add(total, integers[i]);
        // open code down below to see array elements
        //printf("Int Array elements: %d \n", integers[i]);
    }

    printf("\nSum of the Array Elements: %d \n", total);
}

//======================================================================================================//

// Add operation using only bitwise operators
int _add(int a, int b)
{

    // Loop until b is zero
    while (b != 0)
    {

        // Find carry 1 bits - a AND b assign to carry
        int carry = a & b;

        // Find non carry 1 bits - a XOR b assign to a
        a = a ^ b;

        // Multiply carry by 2 by shift and assign to b
        b = carry << 1;
    }

    return a;
}

//======================================================================================================//

// Safe add operation
int add(int a, int b)
{
    // Declare int for result
    int res = 0;
    // Call to _add() a and b and assign to result
    res = _add(a, b);

    // Check for overflow - look at page 90 in book
    if (a > 0 && b > 0 && res < -2147483648) // got this overflow number from google
    {
        printf("OVERFLOW");
        exit(1);
    }
    // Check for underflow - look at page 90 in book
    if (a < 0 && b < 0 && res > 2147483647) // got this overflow number from google
    {
        printf("UNDERFLOW");
        exit(2);
    }

    return res;
}

//======================================================================================================//