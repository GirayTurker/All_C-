#include <stdio.h>
#include <math.h>
#define PI 3.14159
int main(int argc, char *argv[])
{
    // Declare variables
    double radius = 0.0;     // Radius of circle input
    double side = 0.0;       // Side of square input
    double areaCircle = 0.0; // Area of circle
    double areaSquare = 0.0; // Area of square
    double difference = 0.0; // Difference output

    // Get radius
    printf("\nEnter radius: ");
    scanf("%lf", &radius);
    // Get side
    printf("\nEnter side: ");
    scanf("%lf", &side);

    //	Calculate area of circle areaCircle = PI * radius * radius;

    printf("\nThe area of the circle is: %lf\n", areaCircle);
    //	Calculate area of square
    areaSquare = side * side;

    printf("\nThe area of the square is: %lf\n", areaSquare); // Calculate difference

    difference = fabs(areaCircle - areaSquare);

    // Print difference to screen

    printf("\nThe difference is: %lf\n", difference);

    printf("\nPress a key to exit");
}
