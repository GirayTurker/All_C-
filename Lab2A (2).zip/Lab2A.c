#include <stdio.h>

int sum();
double avg();

int main()
{
    int result;
    int n;
    int userNums;
    printf("\nHow many number will be calculated:");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        printf("\nEnter the integer number:");
        scanf("%d", &userNums);
        result = sum(userNums);
    }

    printf("\nThe sum of the first %d integers is: %d\n", n, result);
    double avgResult = avg(result, n);
    printf("\nThe average of the first %d integers is: %.1f\n", n, avgResult);
} // end of main function

int sum(int n)
{
    int total = 0;
    for (int i = 1; i <= n; i++)
    {
        total += i;
    }
    return total;
} //end of int sum function

double avg(int total, int m)
{

    return total / m;

} //end of int avg function