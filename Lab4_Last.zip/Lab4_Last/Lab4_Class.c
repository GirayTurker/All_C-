#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char *read_file(unsigned long *size, char *file_name);
void file_write(unsigned long size, char *output, char *file_name);
char *make_rand_key(unsigned long lengt_of_key, char *key);
char *encrypt(char *clear_file, char *key_file, char *cipher_file);
char *decrypt(char *key_file, char *cipher_file, char *message_file);

int main()
{

    char *orig_file = "read.txt";
    char *random_key_file = "key.txt";
    char *cipher_file = "cypher.txt";
    char *message_file = "messagefile.txt";

    unsigned long size;
    char *string = read_file(&size, orig_file);
    //printf("%d\n", size);
    printf("string: %s", string);

    char *fname = "writefile.txt";
    file_write(size, string, fname);
    free(string);

    int choice;

    do
    {
        printf("\nEncrypt a file: 1");
        printf("\nDecrypt a file: 2");
        printf("\nExit a file: 3");
        printf("\nEnter a choice: ");

        scanf("%d", &choice);

        if (choice == 1)
        {
            char *clearString = read_file(&size, orig_file);
            char *key;
            key = make_rand_key(size, key);
            file_write(size, key, random_key_file);
            encrypt(clearString, random_key_file, cipher_file);
            printf("File Encrypted Successfully\n ");
        }
        else if (choice == 2)
        {
            decrypt(random_key_file, cipher_file, message_file);
            printf("File Decrypted Successfully\n ");
        }

        else if (choice == 3)
        {
            printf("You choose exit!");
        }

    } while (choice != 3);

    return 0;

} //end main()

//----------------------Random Key Generator Function----------------------//
char *make_rand_key(unsigned long lengt_of_key, char *key)
{

    //key = (char *)malloc((int)lengt_of_key + 1);
    //FILE *file = fopen("key.txt", "ky");
    key[lengt_of_key + 1];
    int i;

    //Generate Random chars in ASCII table (based on all range of it)
    for (i = 0; i < lengt_of_key; i++)
    {
        key[i] = rand() % 256;

    } //end for

    key[i] = '\0';

    /*for (i = 0; i < lengt_of_key; i++)
    {
        putc(key[i], file);
    } //end for*/

    return key;

} //end char *make_rand_key()

//----------------------Random Key Generator Function----------------------//

//----------------------Read File Function----------------------//

char *read_file(unsigned long *size, char *file_name)
{

    FILE *file = fopen(file_name, "rb");

    if (file == NULL)
    {
        printf("File can not open!");
        exit(0);
    } //end if (file == NULL)

    int len = 0;
    while (getc(file) != EOF)
    {
        len++;
    }

    *size = len;

    //printf("Pointer Size: %d\n", *size);

    //printf("Lenght: %d\n", len);

    char *store = (char *)malloc(*size * sizeof(char));

    char ch[len + 1];

    rewind(file);

    int i = 0;

    for (i = 0; i < len; i++)
    {
        ch[i] = getc(file);
        store[i] = ch[i];
    }

    store[i] = '\0';

    //printf("STORE: %s\n", store);

    fclose(file);

    return store;

} //end char *read_file()

//----------------------Read File Function----------------------//

//----------------------Write File Function----------------------//

void file_write(unsigned long size, char *output, char *file_name)
{

    /*for (unsigned long i = 0; i < size; i++)
    {

        printf("%c :", output[i]);

    } //end for

    printf("CLear File\n");

    //printf("OUTPUT%s\n:", output);*/

    FILE *file = fopen(file_name, "w");

    fwrite(output, 1, size, file);

    fclose(file);

} //end int file_write

//----------------------Write File Function----------------------//

//----------------------Encrypt File Function----------------------//

char *encrypt(char *clear_file, char *key_file, char *cipher_file)
{

    int i;

    unsigned long len = strlen(clear_file);

    //Generate the cipher text
    char cipher[len + 1];

    for (i = 0; i < len; i++)
    {
        cipher[i] = clear_file[i] ^ key_file[i];

    } //end for

    cipher[i] = '\0';

    file_write(len, cipher, cipher_file);

    return cipher_file;

} //end char *encrypt

//----------------------Encrypt File Function----------------------//

//----------------------Decrypt File Function----------------------//

char *decrypt(char *key_file, char *cipher_file, char *message_file)
{

    int i;

    unsigned long len = strlen(cipher_file);

    char messageFile[len + 1];

    for (i = 0; i < len; i++)
    {
        messageFile[i] = cipher_file[i] ^ key_file[i];

    } //end for

    messageFile[i] = '\0';

    file_write(len, messageFile, message_file);

    return message_file;

} //end char* decrypt

//----------------------Decrypt File Function----------------------//