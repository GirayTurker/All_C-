#include <stdio.h>

// functions initializations
void userInput(char *);
int getLenght(char *);
int chkLowerCase(char);
char convertToUpper(char);
void reverseString(char *);
int capitalizeChars(char *);
void printOutput(char *);

int main(void)
{

    char str[100];
    userInput(str);
    printOutput(str);

    /*//temperoray array to store string which entered by user (user input)
    char str[maxChar];
    //lenght of the String
    int lenght;
    //total capatalized chars
    int capitalized;
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("Enter a String:");
    userInput(str);
    getLenght(str, &lenght);
    reverseString(str, lenght);
    capitalized = capitalizeChars(str, lenght);
    printf("Output Should be:\n");
    printOutput(str, lenght);
    printf("The string is %d chars and %d chars were capatalized.\n", lenght,
           capitalized);*/

} //end main()

//Function to get the lenght of the String
int getLenght(char *str)
{

    int i, lenght = 0;
    //measure the lenght of the string
    for (i = 0; str[i] != '\0'; ++i)
        lenght = i;
    return lenght + 1;

} //end void getLenght(char*str,int*lenght)

//Function to test if a char is lower case
int chkLowerCase(char c)
{

    if (c >= 'a' && c <= 'z')
        return 1;
    else
        return 0;

} //end int chkLowerCase(char c)

// function to convert lower case characters to upper case characters
char convertToUpper(char c)
{

    //Based on ASCII value
    return c - 32;

} // end char convertToUpper ()

// function to get STRING user input
void userInput(char *str)
{

    printf("Enter a string: ");

    gets(str);

} // end userInput()

//Function to reverse string
void reverseString(char *str)
{
    int l = getLenght(str);

    char temp;

    for (int i = 0; i < l / 2; i++)

    {

        temp = str[i];

        str[i] = str[l - i - 1];

        str[l - i - 1] = temp;
    }

} //end void reverseString()

//Function to capitalize all alpha chars and count number capitalized
int capitalizeChars(char *str)
{

    int total = 0;

    int l = getLenght(str);

    for (int i = 0; i < l; i++)

    {

        if (chkLowerCase(str[i]))

        {

            total++;

            str[i] = convertToUpper(str[i]);
        }
    }

    return total;

} //end int capitalizeChars(char* str, int lenght)

//Function to print output
void printOutput(char *str)
{

    int l = getLenght(str);

    reverseString(str);

    int total = capitalizeChars(str);

    for (int i = 0; i < l; i++)

        printf("%c\n", str[i]);

    printf("The string is %d chars and %d chars were capitalized.\n", l, total);

} //end void printOutput(char* str, int lenght)